---
name: Ag-Tech Precision
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3e4850'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6e7881'
  outline-variant: '#bdc8d1'
  surface-tint: '#00658d'
  primary: '#00658d'
  on-primary: '#ffffff'
  primary-container: '#00aeef'
  on-primary-container: '#003e58'
  inverse-primary: '#82cfff'
  secondary: '#435e8f'
  on-secondary: '#ffffff'
  secondary-container: '#acc7fe'
  on-secondary-container: '#375282'
  tertiary: '#c0000c'
  on-tertiary: '#ffffff'
  tertiary-container: '#ff7b6c'
  on-tertiary-container: '#790004'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c6e7ff'
  primary-fixed-dim: '#82cfff'
  on-primary-fixed: '#001e2d'
  on-primary-fixed-variant: '#004c6b'
  secondary-fixed: '#d7e2ff'
  secondary-fixed-dim: '#acc7fe'
  on-secondary-fixed: '#001b3f'
  on-secondary-fixed-variant: '#2a4676'
  tertiary-fixed: '#ffdad5'
  tertiary-fixed-dim: '#ffb4aa'
  on-tertiary-fixed: '#410001'
  on-tertiary-fixed-variant: '#930007'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
  sky-blue-light: '#87CEEB'
  cloud-white: '#F8FAFC'
  navy-deep: '#0B2D5B'
  navy-midnight: '#061A35'
  scarlet-red: '#E30613'
  scarlet-crimson: '#B8050F'
  border-subtle: '#E2E8F0'
  surface-card: '#FFFFFF'
  surface-canvas: '#F8FAFC'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  caption:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4.5rem
---

## Brand & Style

This design system delivers a high-performance, grounded, and modern ag-tech aesthetic tailored for commercial farm owners, fleet managers, and agricultural operators across Gauteng, South Africa. It bridges the critical intersection between precision digital software tools (telematics, field management, diagnostics) and rigorous physical fleet maintenance (on-site machinery detailing, decontamination, mechanical protection).

The visual language combines **Corporate Modernism** with **Industrial Tactility**:
- **Reliability & Clarity:** Clean layouts with ample breathing room to prevent cognitive fatigue during demanding field operations and daylight outdoor viewing.
- **Dual Visual Parity:** Balanced 50/50 visual weight given to digital farm management software tools and tactile on-site machinery detailing services.
- **High-Contrast Precision:** Crisp surface definitions, sharp functional typography, and decisive actionable triggers that meet WCAG 2.2 AA standards under harsh African daylight conditions.
- **Bilingual & Resilient Utility:** Structured for concise English and Afrikaans copy, optimized for instantaneous loading across intermittent 3G/LTE agricultural network environments.

## Colors

The color palette establishes immediate brand recognition while preserving functional contrast and readability across rugged agricultural contexts:

- **Primary (`#00AEEF` / Sky Blue):** Represents digital forward-momentum, technology, and clarity. Used for primary focus indicators, active interactive triggers, technological accents, and active tab highlights. `sky-blue-light` (`#87CEEB`) serves as a secondary tint for subtle pill fills, hover states on dark surfaces, and soft icon badges.
- **Secondary (`#0B2D5B` / Agrijuune Navy):** Anchors the interface with institutional stability, operational rigor, and deep mechanical authority. Used for primary typography, primary action buttons, key brand headers, and high-impact structural containers.
- **Tertiary (`#E30613` / Scarlet Red):** A dynamic, decisive industrial accent inspired by agricultural machinery trim and telemetry indicators. Reserved strictly for critical emphasis, destructive warnings, emergency scheduling, operational badges, and key conversion moments. Never overused.
- **Neutral & Surfaces (`#F8FAFC`, `#64748B`, `#0B2D5B`):** Canvas backgrounds use `cloud-white` (`#F8FAFC`) to minimize glare in sunlight. High-density UI text uses `#0B2D5B` on light backgrounds to surpass WCAG 2.2 AAA contrast standards. Subtle borders (`#E2E8F0`) keep containers distinct without visual clutter.

## Typography

Typography balances clean European geometric precision with high legibility across English and Afrikaans agricultural terms:

- **Headline & Body Stack (Plus Jakarta Sans):** Selected for its crisp geometric proportions, wide aperture, and human touch. It ensures fatigue-free reading across diagnostic reports, service tier breakdowns, and fleet tracking dashboards. Body text strictly maintains a 16px minimum floor on standard viewports to guarantee accessibility under harsh ambient light.
- **Label & Data Stack (Space Grotesk):** Provides a technological, telemetry-oriented voice for machinery serials, operational specs, metric meters, and data pills (e.g., `"SAMPLE DATA — FOR DEMONSTRATION"`). The subtle monospaced geometry communicates precision and industrial grade calibration.
- **Vertical Rhythm & Scale:** Font hierarchies scale down smoothly using mobile-specific tokens (`display-hero-mobile`, `headline-lg-mobile`) to prevent awkward line breaks on rugged smartphone devices.

## Layout & Spacing

The layout philosophy follows a responsive, fluid 12-column grid designed for modularity, field-inspection dashboards, and side-by-side service comparisons:

- **Base Unit:** Strictly structured around an `8px` spatial scale (`space-xs` = 4px, `space-sm` = 8px, `space-md` = 16px, `space-lg` = 24px, `space-xl` = 32px, `space-2xl` = 48px, `space-3xl` = 72px).
- **Interactive Target Minimums:** Every interactive target (CTA buttons, selector toggles, calendar pickers, filter badges) adheres to a strict `48px` minimum bounding box to enable seamless gloved or one-handed field interaction.
- **Responsive Fluidity:**
  - **Desktop (> 1024px):** 12 columns, 24px gutters, max canvas container of 1280px with centered margins. Digital Farm Tools and Detailing Services maintain equal 6-column widths side-by-side to reflect 50/50 organizational priority.
  - **Tablet (640px – 1024px):** 8 columns, 20px gutters, dynamic reflow for split-card matrices.
  - **Mobile (< 640px):** 4 columns, 16px gutters, 16px horizontal canvas margins. Grid collapses into full-width stacked modules with vertical ordering prioritizing high-urgency operations first.

## Elevation & Depth

Elevation eschews heavy fantasy drop-shadows in favor of crisp industrial tactility, high contrast separation, and daylight-resilient ambient layers:

- **Surface Container Tiering:** Depth is primarily established through tonal shifts:
  - **Base Canvas:** `cloud-white` (`#F8FAFC`).
  - **Level 1 (Card/Container Surfaces):** Pure White (`#FFFFFF`) with a 1px solid border of `#E2E8F0`.
  - **Level 2 (Raised Components / Modals / Popovers):** Pure White with a diffused ambient shadow (`0 4px 16px -2px rgba(11, 45, 91, 0.08)`) and a crisply rendered top edge stroke.
  - **Level 3 (Tactile Hover & Drag States):** Elevated shadow (`0 10px 24px -4px rgba(11, 45, 91, 0.12)`), signaling mechanical tangibility without visual mud.
- **Structural Outlines:** Every card and modular panel features a dedicated 1px border. In high-glare environments, borders ensure panel separation where soft shadows might wash out completely.
- **Hero Staging:** WebGL interactive models and 3D machinery elements render over smooth radial ambient gradients of `#0B2D5B` to `#061A35`, anchoring digital tech visuals against heavy industrial machinery.

## Shapes

The design system employs a **Rounded** shape profile (`roundedness: 2`):

- **Default UI Components:** 8px (`0.5rem`) corner radius for standard buttons, inputs, dropdown menus, and data badges. This balances modern engineering precision with ergonomic approachability.
- **Cards & Primary Modules (`rounded-lg`):** 16px (`1rem`) corner radius for service comparison containers, diagnostic charts, vehicle detailing summaries, and modals.
- **Hero Banners & Floating Overlays (`rounded-xl`):** 24px (`1.5rem`) corner radius for high-impact interactive containers and marketing highlights.
- **Pills & Status Indicators:** Full capsule curves (`9999px`) reserved specifically for categorical tag pills, operational status meters (`ACTIVE`, `SCHEDULED`, `SAMPLE DATA`), and floating quick-filter triggers.

## Components

### Buttons & Interactive Controls
- **Primary Button (Deep Navy Action):** Background `#0B2D5B`, text `#FFFFFF`, 8px corner radius, 48px minimum height. On hover, background shifts to `#061A35` with an accent underline or subtle border glow in `#00AEEF`.
- **Secondary Button (Sky Blue Tech):** Background `#00AEEF`, text `#0B2D5B` (or `#FFFFFF`), high-contrast focus rings (`3px solid rgba(0, 174, 239, 0.4)`).
- **Tertiary / Urgent Action (Scarlet Red):** Background `#E30613`, text `#FFFFFF`. Reserved for emergency field maintenance call-outs, service booking locks, and critical system alerts.
- **Outlined / Ghost Button:** Background transparent, 1.5px solid border `#0B2D5B`, text `#0B2D5B`, background filling with `rgba(11, 45, 91, 0.04)` on hover.

### Service Cards (50/50 Dualism)
- **Farm Management Technology Card:** Pure White `#FFFFFF` surface, 1px `#E2E8F0` border, 16px radius, accented with a 4px top edge in `#00AEEF`. Features digital telemetry icons, interactive tech specs, and software walkthrough previews.
- **Agricultural Machinery Detailing Card:** Pure White `#FFFFFF` surface, 1px `#E2E8F0` border, 16px radius, accented with a 4px top edge in `#E30613`. Features machinery staging badges, detailing process meters, chemical compliance data, and direct booking triggers.
- **Visual Parity:** Both cards share identical padding (`space-xl`), identical header typography scales (`headline-sm`), and identical CTA dimensions.

### Data Chips & Status Badges
- **Demonstration Pill:** Background `rgba(0, 174, 239, 0.1)`, text `#0B2D5B`, border `1px solid rgba(0, 174, 239, 0.3)`, typography `label-md` (`Space Grotesk`, uppercase). Displays `"SAMPLE DATA — FOR DEMONSTRATION"`.
- **Active / Operational Badge:** Background `#E6F9F0`, text `#0F766E`, circular 6px status indicator.
- **Maintenance Due Badge:** Background `rgba(227, 6, 19, 0.1)`, text `#E30613`, bold icon indicator.

### Input Fields & Form Controls
- **Text Inputs & Dropdowns:** 48px height, 8px radius, `#FFFFFF` fill, 1.5px border in `#CBD5E1`. Placeholder text in `#64748B`.
- **Active Focus State:** 2px border `#00AEEF` accompanied by an ambient `0 0 0 3px rgba(0, 174, 239, 0.2)` ring. Floating label shifts to `label-md` in `#0B2D5B`.
- **Field Error State:** 1.5px border `#E30613`, error helper message beneath in 12px Plus Jakarta Sans bold with an inline alert icon.
- **Checkboxes & Radios:** 20px × 20px touch targets padded to 48px touch bounding box. Filled with `#0B2D5B` or `#00AEEF` on selection.

### Regional Coverage Graphic (Gauteng Focus)
- Stylized, vector-based topological outline of the Gauteng province. Highlights core agricultural corridors without hyper-granular GPS boundaries to manage operational service delivery expectations realistically.